from django.contrib import admin

from .models import ClientModel

# Register your models here.

admin.site.register(ClientModel)